import sys, os
import datetime
import struct
import traceback

     
from_unicorn = {'2B':'H', '2C':'I'}

to_unicorn = {'2B':'B', '2C':'C'}

pktype = {'info':'+', 'stara' : 'S'}


crctable = [ 0, 94,188,226, 97, 63,221,131,194,156,126, 32,163,253, 31, 65,
                                      157,195, 33,127,252,162, 64, 30, 95,  1,227,189, 62, 96,130,220,
                                      35,125,159,193, 66, 28,254,160,225,191, 93,  3,128,222, 60, 98,
                                      190,224,  2, 92,223,129, 99, 61,124, 34,192,158, 29, 67,161,255,
                                      70, 24,250,164, 39,121,155,197,132,218, 56,102,229,187, 89,  7,
                                      219,133,103, 57,186,228,  6, 88, 25, 71,165,251,120, 38,196,154,
                                      101, 59,217,135,  4, 90,184,230,167,249, 27, 69,198,152,122, 36,
                                      248,166, 68, 26,153,199, 37,123, 58,100,134,216, 91,  5,231,185,
                                      140,210, 48,110,237,179, 81, 15, 78, 16,242,172, 47,113,147,205,
                                      17, 79,173,243,112, 46,204,146,211,141,111, 49,178,236, 14, 80,
                                      175,241, 19, 77,206,144,114, 44,109, 51,209,143, 12, 82,176,238,
                                      50,108,142,208, 83, 13,239,177,240,174, 76, 18,145,207, 45,115,
                                      202,148,118, 40,171,245, 23, 73,  8, 86,180,234,105, 55,213,139,
                                      87,  9,235,181, 54,104,138,212,149,203, 41,119,244,170, 72, 22,
                                      233,183, 85, 11,136,214, 52,106, 43,117,151,201, 74, 20,246,168,
                                      116, 42,200,150, 21, 75,169,247,182,232, 10, 84,215,137,107, 53 ]


def getcrc(dat):
    crc = 0
    for c in dat:
        crc = crctable[crc ^ ord(c)]
        #print format(crc, 'X'),
    return crc


def printout(strout):
    if g_silent == 0:
        sys.stdout.write(strout)
    logf_txt.write(strout)
    logf_txt.flush()

def printhex(strr):
    printout(' [')
    for cc in strr:
        printout(hex(ord(cc)) + ' ')
    printout('] ')


def up_send(sendstr):
    up_port.write(sendstr)
    up_blogout.write(sendstr)
    up_blogout.flush()

def up_getc(n=1):
    cc = up_port.read(n)
    if len(cc) > 0:
        up_blogin.write(cc)
        up_blogin.flush()
    return cc

def down_send(sendstr):
    down_port.write(sendstr)
    down_blogout.write(sendstr)
    down_blogout.flush()

def down_getc(n=1):
    cc = down_port.read(n)
    if len(cc) > 0:
        down_blogin.write(cc)
        down_blogin.flush()
    return cc

def check_result(result):
    printout(result)
    if len(result) > 2 and result[1] == 'O':
        
        return 1
    printout(' radio operation failed \r\n')
    return 0
    


''' use this function to initialize the radios
'''
def init(uplink, downlink, port_timeout, silent = 0):
    global logf_txt, down_blogout, down_blogin
    global up_blogin, up_blogout, down_port, up_port
    global g_silent, timeout_radio, getpk_timeout
    global radio_mtu

    g_silent = silent

    down_port = downlink
    up_port = uplink

    try:
        os.mkdir('logs')
    except:
        pass
    
    radio_mtu = 60

    # set getpk timeout here
    getpk_timeout = port_timeout * 1000 * 1.5  # ms
    
    # make it global
    timeout_radio = port_timeout  # seconds

    try:
    
        logfn = 'logs\\' + datetime.datetime.now().strftime("%Y-%m-%d_%H.%M.%S.gnd.txt")
        logf_txt = open(logfn,'wb')
        print logfn
    
        fname = 'logs\\' + datetime.datetime.now().strftime("%Y-%m-%d_%H.%M.%S.gnd_down_in.bin")
        down_blogin = open(fname,'wb')
        print fname
    
        fname = 'logs\\' + datetime.datetime.now().strftime("%Y-%m-%d_%H.%M.%S.gnd_down_out.bin")
        down_blogout = open(fname,'wb')
        print fname
    
        fname = 'logs\\' + datetime.datetime.now().strftime("%Y-%m-%d_%H.%M.%S.gnd_up_out.bin")
        up_blogout = open(fname,'wb')
        print fname
    
        fname = 'logs\\' + datetime.datetime.now().strftime("%Y-%m-%d_%H.%M.%S.gnd_up_in.bin")
        up_blogin = open(fname,'wb')
        print fname
        
    except:
        print traceback.print_exc()
    
    printout('uplink:')
    result_up = up_working_mode()
    printout('downlink:')
    result_down = down_working_mode()
    
    return (result_up, result_down)



def checkpk(pk):
    pknew = ''

    prevc = ''
    #print
    
    for c in pk:
        if prevc == '\xdb' and c == '\xdc':
            pknew += '\xc0'
        elif prevc == '\xdb' and c == '\xdd':
            pknew += '\xdb'
        elif c != '\xdb':
            pknew += c
        prevc = c
    crc = getcrc(pknew[:-1])
    #for c in pknew[:-1]:
        #printout( hex(ord(c)))
        #crc = crctable[crc ^ ord(c)]
    if crc != ord(pknew[-1]):
        #pass
        printout ('CRC_error ['+ hex(crc) + ' != ' + hex(ord(pknew[-1])) +']' )
        printhex(pknew)
        #return pknew
        return ''
    
    printout ('CRC_OK ['+ hex(crc) + ' = ' + hex(ord(pknew[-1])) +']' )
    return pknew

def sanitize(pkdat):
    clean = ''
    for c in pkdat:
        if c == '\xc0':
            clean += '\xdb\xdc'
        elif  c == '\xdb':
            clean += '\xdb\xdd'
        else:
            clean += c
    return clean

''' use this funciton to send typ='S' packets  (or any other type)
to satellite to_unicorn['2B'] or to_unicorn['2C']
it populates the crc and the header
'''
def sendpk(fromto, typ, pkstr):
    crc = 0

    for c in pkstr:
        crc = crctable[crc^ord(c)]
        
    pkstr += chr(crc)
    pknew = sanitize(pkstr)

    pklen = len(pknew)

    #sanitize len as well 0xc0 = 192;  0xdb = 219
    if pklen >= 0xc0:
        pklen += 1
    if pklen >= 0xdb:
        pklen += 1
        
    if pklen > radio_mtu:
        printout(' error: packet too big ')
        return 'error'

    lenbin = chr(pklen)
    full = '|K|\xc0' + fromto + typ + lenbin + lenbin + pknew + '\xc0|E|'
    sendlen = len(full)-6
    if (sendlen > 60):
        printout("error: packet too large to send, need to chunk it!")
        return 'error'
        
    up_send(full)
    result = up_getc(10)
    tlen = 0
    if len(result) > 6:
        tlen = str(ord(result[6]))
    printout(' sendpk crc = ' + hex(crc) + '  len = ' + str(sendlen) 
             + ' tlen= ' + str(tlen) + result + '\r\n')
    
    #expected result: |OK|T_x|E|
    if not check_result(result):
        result += up_getc(10)
        printout(' sendpk error ' + result)
    return result



''' use this function to listen for packets
    set timeout in init
'''
def getpk():
    tout = getpk_timeout

    c = ''
    while tout > 0:

        c = down_getc()
        pkrssi = 0
     
        if len(c) == 0:
            tout -= timeout_radio * 1000
            continue
        
        tout -= 1 # take 1 ms off for every byte
        if ord(c) >= 32 and ord(c) <= 126:
            printout(c)
        else:
            printhex(c)

        if c == '\xc0':
            printout( datetime.datetime.now().strftime("\r\n %Y-%m-%d_%H.%M.%S , ") )
            printout( ' sync ')
            pkrssis = down_getc(2)
            
            if len(pkrssis) == 2:
                ssimsb = (ord(pkrssis[0])<<4)
                ssilsb = ord(pkrssis[1])
                pkrssi = ( ssimsb + ssilsb) - 157  #sx1276 datasheet 
                printout(' rssi = ' + str(pkrssi) + ' dBm ' )
                
            header = down_getc(4)
            
            if len(header) < 4:
                printout(' ser read header timeout error ')
                continue
            # 0 crc8 1 * 2 len 3 len 4 ser_msb 5 ser_lsb
            fromto = header[0]
            typ = header[1]

                           
            pksize = ord(header[2])
            pksize2 = ord(header[3])
            
            if pksize != pksize2:
                printout( ' len_error (!) ' + str(pksize) + ' ' + str(pksize2) + '  ')
                continue

            # len gets incremented if c0 or higher and if db or higher, so do the reverse
            if pksize > 219:
                pksize -= 1
            if pksize > 192:
                pksize -= 1
                
            printout(' len = ' + str(pksize))

            if pksize < 100:
                pass
                #printout(' short packet (!) ')

            # header is NOT included in len
            packet = down_getc(pksize)

           
            if len(packet) < pksize:
                printout(' error: ser_read_timeout_packet ')
                continue

            pkend = down_getc(3)  # |E|
            

            printout ( ' read_done ')

            pkdata = checkpk(packet)

            if len(pkdata) < 2:
                printout( ' crc_failed error (!) ')
                #printout(packet)
                continue
            
            ######### after this line the packet is validated and can be used #############
            printout(' getpk done \r\n')
            return (fromto, typ, pkrssi, pkdata)
    #printout(datetime.datetime.now().strftime("\r\n getpk timeout %H%M%S  \r\n"))
    #printout(' getpk fail (timeout?) \r\n')
    return ('','','','') #getpk timed out / failed


def getall():
    data = 'dummy'
    while len(data) > 0:
        (fromto, typ, pkrssi, data) = getpk()
        printpk(fromto, typ, data)
    #printout( ' getall done \r\n')
    #printout('/')


''' use this function to send a TLE string - must have \r\n separating the two lines
must terminate with a \0 byte
e.g.
"1 25544U 97067A   08264.51782528 -.00002182  00000-0 -11606-4 0  2927\r\n2 25544  51.6416 247.4627 0006703 130.5360 325.0288 15.72125391563537\r\n\0"
'''
def cmd_send_tle(to_sat, tlestr):
    #need to chunk the tle, cannot send packets longer than 64 bytes
    
    tle1 = chr(1) + tlestr[:50]
    tle2 = chr(2) + tlestr[50:100]
    tle3 = chr(3) + tlestr[100:]
    printout("\r\n send : "+tle1+tle2+tle3+"\r\n")
    res1 = sendpk(to_sat,'T',tle1)
    res2 = sendpk(to_sat,'T',tle2)
    res3 = sendpk(to_sat,'T',tle3)
    return res1 + res2 + res3

''' use cmd_ functions to control the satellite
you need to call getpk() to listen for at least one response packet(s)

'''

''' sat will respond with two packets
'''
def cmd_get_tm_health(to_sat):
    return sendpk(to_sat, '!', 'GET_TELEMETRY_HEALTH\0\r\n')

''' sat will respond with many packets (hundreds, tbc)
read them all before sending other commands
'''
def cmd_get_tm_orbit(to_sat):
    return sendpk(to_sat, '!', 'GET_TELEMETRY_ORBIT\0\r\n')

''' initial telemetry, right after ejection from the pod
(many packets)
'''
def cmd_get_tm_init(to_sat):
    return sendpk(to_sat, '!', 'GET_TELEMETRY_INIT\0\r\n')

def cmd_adcs_off(to_sat):
    return sendpk(to_sat, '!', 'ADCS_OFF\0\r\n')

def cmd_adcs_reset(to_sat):
    return sendpk(to_sat, '!', 'ADCS_RESET\0\r\n')

def cmd_radios_kill_all(to_sat):
    return sendpk(to_sat, '!', 'RADIOS_KILL_ALL\0\r\n')

def cmd_radio_uhf_kill(to_sat):
    return sendpk(to_sat, '!', 'RADIO_UHF_KILL\0\r\n')

def cmd_radio_sband_kill(to_sat):
    return sendpk(to_sat, '!', 'RADIO_SBAND_KILL\0\r\n')

''' isl is the payload in this case
'''
def cmd_payload_kill(to_sat):
    return sendpk(to_sat, '!', 'PAYLOAD_KILL\0\r\n')


def freq_to_bytes(freq):
    b1 = chr(freq&0xff)
    b2 = chr( (freq>>8) & 0xff )
    b3 = chr( (freq>>16) & 0xff )
    b4 = chr( (freq>>24) & 0xff )
    vals = b1 + b2 + b3 + b4
    return vals


def up_sleep_mode():
    up_send('|M|S|E|')
    result = up_getc(10)
    return check_result(result)

def up_working_mode():
    up_send('|M|W|E|')
    result = up_getc(10)
    return check_result(result)

def down_sleep_mode():
    down_send('|M|S|E|')
    getall()
    return 1

def down_working_mode():
    down_send('|M|W|E|')
    result = down_getc(10)
    return check_result(result)


''' use radio_ functions to change the radio frequency / power
'''
def radio_change_freq_up_txrx(freq):
    up_sleep_mode()
    
    up_send('|F|T' + freq_to_bytes(freq) + '|E|')
    freq_res = up_getc(10)
    up_send('|F|R' + freq_to_bytes(freq) + '|E|')
    freq_res += up_getc(10)
    
    up_working_mode()
    
    return freq_res

def radio_change_freq_down_txrx(freq):
    down_sleep_mode()
    
    down_send('|F|T' + freq_to_bytes(freq) + '|E|')
    freq_res = down_getc(10)
    down_send('|F|R' + freq_to_bytes(freq) + '|E|')
    freq_res += down_getc(10)
    
    down_working_mode()
    
    return freq_res
    
def radio_change_power_uplink(pwr):
    up_sleep_mode()
    up_send('|P|' + chr(pwr) + '|E|')
    result = up_getc(10)
    printout(result)
    up_working_mode()
    return result

def radio_change_power_downlink(pwr):
    down_sleep_mode()
    down_send('|P|' + chr(pwr) + '|E|')
    result = down_getc(10)
    printout(result)
    down_working_mode()
    return result


''' use printpk function to print and parse (telemetry) packets
'''
def printpk(fromto, pktyp, pkdata):

    if pktyp == '~':
        printout(' beacon! ')
        printout(pkdata[:-1])

    if pktyp == '+':
        printout (' info = ' + pkdata[:-1])
      
    if pktyp == '#':
        printout(' adcs_telemetry packet len = ' + str(len(pkdata)) + '\r\n')
        ix = 0
        tmlen = 52
        # I:ui32 B:ui8 h:i16 b:i8 H:ui16
        adcs_tm = struct.unpack('I6B3h3b3bb8b3b3b3b10BbB',pkdata[:tmlen])
        printout(' adcs_tm ' + str(adcs_tm))
        printout(' \r\n')
        
        tm_adcs_keys = ['uptime_adcs', 
                     'rtc_adcs_year', 'rtc_adcs_month', 'rtc_adcs_day', 
                     'rtc_adcs_hour', 'rtc_adcs_minute', 'rtc_adcs_second', 
                     'sat_pos_x', 'sat_pos_y', 'sat_pos_z',
                     'mag_x', 'mag_y', 'mag_z', 
                     'gyro_x', 'gyro_y', 'gyro_z', 
                     'gyro_tempC',
                     
                     'sun1_x1', 'sun1_x2', 'sun1_y1', 'sun1_y2'
                     'sun2_x1', 'sun2_x2', 'sun2_y1', 'sun2_y2'

                     'rpm1', 'rpm2', 'rpm3',
                     'rwd1', 'rwd2', 'rwd3',
                     'mtq1', 'mtq2', 'mtq3',
                     
                     'adc_adcs_1', 'adc_adcs_2', 'adc_adcs_3', 'adc_adcs_4',
                     'adc_adcs_5', 'adc_adcs_6', 'adc_adcs_7', 'adc_adcs_8',
                     'adc_adcs_9', 'adc_adcs_10',
                     
                     'mode_adcs', 
                     'crc_adcs' ]
        
       
        printout('## uptime_adcs, ' + str(adcs_tm[ix]) + '\r\n' )
        
        ix += 1
        printout('   rtc_adcs,    ' + str(adcs_tm[ix:ix+6]) + '\r\n' )
        ix += 6
        printout('   sat_pos,     ' + str(adcs_tm[ix:ix+3]) + '\r\n' )
        ix += 3
        printout('   mag,         ' + str(adcs_tm[ix:ix+3]) + '\r\n' )
        ix+=3
        printout('   gyro,        ' + str(adcs_tm[ix:ix+3]) + '' )
        ix+=3
        printout('   gyro_tempC, ' + str(adcs_tm[ix]) + '\r\n' )
        ix+=1
        printout('   sun_raw,     ' + str(adcs_tm[ix:ix+8]) + '\r\n' )
        ix+=8
        printout('   rpm,         ' + str(adcs_tm[ix:ix+3]) + '\r\n' )
        ix+=3
        printout('   rwd,         ' + str(adcs_tm[ix:ix+3]) + '\r\n' )
        ix+=3
        printout('   mtq,         ' + str(adcs_tm[ix:ix+3]) + '\r\n' )
        ix+=3
        printout('   adc_adcs,    ' + str(adcs_tm[ix:ix+10]) + '\r\n' )
        ix+=10
        printout('   mode_adcs,   ' + str(adcs_tm[ix:ix+1]) + '\r\n' )
        ix+=1
        printout('   crc_adcs,    ' + hex(adcs_tm[ix]) + ' ?= ' + hex( getcrc(pkdata[:tmlen-1]) ) + '\r\n' )
        ix+=1
        printout (pkdata[tmlen:])
        
        adcs_tm_dic = dict(zip(tm_adcs_keys, adcs_tm))
        
        printout(str( adcs_tm_dic))
        
        return adcs_tm_dic

    if pktyp == '?':
        printout(' obc_telemetry packet len = ' + str(len(pkdata)) + '\r\n')
        ix = 0
        tmlen = 45
        # I:ui32 B:ui8 h:i16 b:i8 H:ui16
        obc_tm = struct.unpack('I6BH3B8b3h9BHBBB',pkdata[:tmlen])
        printout('obc_tm ' + str(obc_tm))
        printout(' \r\n')
        
        tm_obc_keys = ['uptime_adcs', 
                     'rtc_adcs_year', 'rtc_adcs_month', 'rtc_adcs_day', 
                     'rtc_adcs_hour', 'rtc_adcs_minute', 'rtc_adcs_second', 
                     'sat_pos_x', 'sat_pos_y', 'sat_pos_z',
                     'mag_x', 'mag_y', 'mag_z', 
                     'gyro_x', 'gyro_y', 'gyro_z', 
                     'gyro_tempC',
                     
                     'sun1_x1', 'sun1_x2', 'sun1_y1', 'sun1_y2'
                     'sun2_x1', 'sun2_x2', 'sun2_y1', 'sun2_y2'

                     'rpm1', 'rpm2', 'rpm3',
                     'rwd1', 'rwd2', 'rwd3',
                     'mtq1', 'mtq2', 'mtq3',
                     
                     'adc_adcs_1', 'adc_adcs_2', 'adc_adcs_3', 'adc_adcs_4',
                     'adc_adcs_5', 'adc_adcs_6', 'adc_adcs_7', 'adc_adcs_8',
                     'adc_adcs_9', 'adc_adcs_10',
                     
                     'mode_adcs', 
                     'crc_adcs' ]
        
        printout('?? uptime_obc,    ' + str(obc_tm[ix]) + '\r\n' )
        ix+=1
       
        printout('   rtc_obc,       ' + str(obc_tm[ix:ix+6]) + '\r\n' )
        ix+=6
        printout('   eps,           ' + str(obc_tm[ix]) + '\r\n' )
        ix+=1

        printout('   rssi,          ' + str(obc_tm[ix:ix+3]) + '\r\n' )
        ix+=3

        printout('   sol_t_all,     ' + str(obc_tm[ix:ix+8]) + '\r\n' )
        ix+=8
        printout('   bat_v_i_t,     ' + str(obc_tm[ix:ix+3]) + ' <<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<<< \r\n' )
        ix+=3
        printout('   adc_obc,       ' + str(obc_tm[ix:ix+9]) + '\r\n' )
        printout('                   (solar_i, payload_i, 3v3_i, 3v3_v, 8v4_i, 8v4_v, uhf_5v_i, sband_5v_i, radio_3v3_i) \r\n')
        ix+=9
        printout('   reset_cnt,     ' + str(obc_tm[ix]) + '\r\n')
        ix+=1
        printout('   tle_crc,       ' + str(hex(obc_tm[ix])) + '\r\n')
        ix+=1
        printout('   isl,           ' + str(hex(obc_tm[ix])) + '\r\n')
        ix+=1
        printout('   crc_obc,       ' + hex(obc_tm[ix]) + ' ?= ' + hex( getcrc(pkdata[:tmlen-1]) ) + '\r\n' )
        ix+=1
        printout (pkdata[tmlen:])
        
        obc_tm_dic = dict(zip(tm_obc_keys, obc_tm))

        printout(str( obc_tm_dic))
        
        
        return obc_tm_dic
               
        
    if len(pktyp) > 0:
        printout('\r\n')
    #printout('.')
    return {}
                    
