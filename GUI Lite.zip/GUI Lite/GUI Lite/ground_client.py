'''
Runs gound.py without the GUI
'''

import ground as gnd
import serial

#
def port_init(sername, serspeed, port_timeout):
 
    # you need to install pyserial to run this:
    # cmd (admin) c:\python27\python.exe -m pip install pyserial
    
    # 2 sec timeout gives the radio enough time to print out a response (worst case)
    serout = serial.Serial(sername, serspeed, timeout=port_timeout)
    
    print (sername + '  ' + str(serspeed) + '\r\n')
    return serout

def serial_init():
    port_timeout = 2

    #downlink = port_init('COM4',230400, port_timeout)
    #uplink = port_init('COM6', 230400, port_timeout)
    
    #gnd.init(downlink, downlink, port_timeout, silent = 0)

def changefreq():
    gnd.radio_change_freq_down_txrx(2400000)

def changepower():
    gnd.radio_change_power_uplink(5)

def testpacket():
    gnd.cmd_get_pic_test( gnd.to_unicorn['2B'], False)
    gnd.getall()

def testlarge(i):
    pkstr = chr(i)
    for i in xrange(49):
        pkstr += chr((i+33)%126)
    gnd.sendpk(gnd.to_unicorn['2B'], gnd.pktype['info'], pkstr)

def testrate():
    for i in xrange(1000):
        testlarge(i%250)
    
#continuously requests tm_health packets and listen for sent packets, printing 
#them
def runloop():
    if __name__ == "__main__":
        while 1:
            (fromto, typ, pkrssi, data) = gnd.getpk()
            gnd.printpk(fromto, typ, data)
             
            gnd.cmd_get_tm_health(gnd.to_unicorn['2B'], False)
            for i in xrange(2):
                (fromto, typ, pkrssi, data) = gnd.getpk()
                gnd.printpk(fromto, typ, data)
        
#serial_init()

#runloop()

#testrate()



