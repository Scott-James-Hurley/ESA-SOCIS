import unittest

from GUI import controller

import Tkinter
import GUI

class TestIsInt(unittest.TestCase):
    #Copy of method from Controller class so a controller object doesn't have
    #to be created
    def is_int(self, s):
        try:
            int(s)
            return True
        except ValueError:
            return False
        
    def testIsInt(self):
        """
        Test that it returns true if given a number
        """ 
        result = self.is_int("1")
        self.assertEqual(result, True)
        
    def testIsNotInt(self):
        """
        Test that it returns false if given a not-a-number
        """ 
        result = self.is_int("n")
        self.assertEqual(result, False)
        
if __name__ == '__main__':
    unittest.main()